# games/__init__.py
# пустой файл для обозначения пакета python