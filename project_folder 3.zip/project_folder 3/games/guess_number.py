import random

def play_guess_number():
    #основная функция игры
    print("\n" + "-" * 50)
    print("Игра 'Угадай число'")
    print("-" * 50)
    print("Я загадал число от 1 до 100")
    print("Попробуй угадать его за минимальное количество попыток!")
    print("-" * 50)
    #компьютер загадывает число
    secret_number = random.randint(1, 100)
    attempts = 0 #счетчик попыток
    max_attempts = 15 #можно поставить любой лимит, но 15, по момему мнению, хорошо подходит
    
    print(f"Подсказка: у тебя есть не более {max_attempts} попыток")
    
    #основной игровой цикл
    while attempts < max_attempts:
        try:
            #получаем догадку игрока
            guess = int(input(f"\nПопытка №{attempts + 1}. Твоя догадка: "))
            
            #проверяем, что число в диапазоне
            if guess < 1 or guess > 100:
                print("Число должно быть от 1 до 100! Попробуй еще")
                continue
            
            attempts += 1
            
            #проверяем догадку
            if guess < secret_number:
                print("Мое число БОЛЬШЕ твоего")
            elif guess > secret_number:
                print("Мое число МЕНЬШЕ твоего")
            else:
                #если игрок угадал:
                print("\n" + "Победа! " * 5)
                print(f"Поздравляю! Ты угадал число {secret_number}!")
                print(f"Тебе понадобилось {attempts} попыток")
                
                #оцениваем результат:
                if attempts <= 5:
                    print("Ты молодец!")
                elif attempts <= 10:
                    print("Хороший результат!")
                else:
                    print("Ты неплохо постарался")
                print("🎉" * 20)
                break
            
            #даём подсказку об оставшихся попытках
            remaining = max_attempts - attempts
            if remaining > 0:
                print(f"Осталось попыток: {remaining}")
            else:
                print("Это была последняя попытка!")
                
        except ValueError:
            print("Ошибка! Нужно ввести именно число. Попробуй еще раз")
    
    #если попытки закончились:
    if attempts >= max_attempts and 'guess' in locals() and guess != secret_number:
        print("\n" + "💀" * 7)
        print("Ты проиграл")
        print("К сожалению, попытки закончились!")
        print(f"Я загадал число: {secret_number}")
        print("В следующий раз повезет больше!")
    
    #предлагаем сыграть ещё раз:
    print("\n" + "-" * 50)
    while True:
        play_again = input("Хотите сыграть еще раз в Угадай число? (да/нет): ").lower()
        
        if play_again in ['да', 'д', 'yes', 'y']:
            print("\n" + "*" * 50)
            play_guess_number() #вызов для новой игры
            break
        elif play_again in ['нет', 'н', 'no', 'n']:
            print("\nВозвращаюсь в главное меню...")
            break
        else:
            print("Пожалуйста, введите 'да' или 'нет'")

#блок для самостоятельного тестирования игры
if __name__ == "__main__":
    play_guess_number()